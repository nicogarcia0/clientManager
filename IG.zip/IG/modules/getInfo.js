const getIp = require('getpubip')
const axios = require('axios')
const ip = getIp.getPubIp()
const fs = require('fs')
const { timeStamp } = require('console')

var fechaActual = new Date();
var day = fechaActual.getDate();
var month = fechaActual.getMonth() + 1; 
var year = fechaActual.getFullYear();
var hour = fechaActual.getHours();
var min = fechaActual.getMinutes();
var seg = fechaActual.getSeconds();

// Formatear la fecha y hora
var fechaFormateada = day + '/' + month + '/' + year;
var horaFormateada = hour + ':' + min + ':' + seg;
var conjunto = fechaFormateada + "  " + horaFormateada
// Obtener geolocalizacion

async function geoIp(ip) {
    try {
        const response = await axios.get('http://ip-api.com/json/' + ip)
        const data = response.data
        return data        
    } catch (error) {
        throw error
    }
}

// Mostrar geolocalizacion

function showGeo(geo) {
    console.log("Pais: " + geo.country)
    console.log("Region: " + geo.regionName)
    console.log("Ciudad: " + geo.city)
    console.log("CP: " + geo.zip)
    console.log("Latitud: " + geo.lat)
    console.log("Longitud: " + geo.lon)
    console.log("Proovedor: " + geo.as)
    console.log("IP: " + geo.query)
}

// Log hora

function generateLog(time, geo, url) {
    let log = "\nConexion entrante.\nIP: " + geo.query + "\nUrl: " + url +"\nPais: " +geo.country+"\nCiudad: " + geo.city + "\nProovedor: " + geo.as + "\nFecha y hora: " + time + "\n--------------------------------------------------------------------"
    console.log(log)
    fs.appendFileSync('logs.txt', log)
}





// Ejecucion principal
async function main(url) {
    const geo = await geoIp(ip)
    generateLog(conjunto, geo, url)
}




module.exports = { main }